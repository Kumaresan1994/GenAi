class OllamaAPI {
  constructor() {
    this.baseUrl = 'http://localhost:11434/api/generate'; // Directly to Ollama's API
  }

  // Helper function to extract the entire code block (including the delimiters)
  extractBlock(text) {
    const regex = /(```[\s\S]*?```)/;
    const match = text.match(regex);
    return match && match[1] ? match[1].trim() : text;
  }

  async sendMessage(prompt, model = 'qwen2.5:3b') {
    try {
      const response = await fetch(this.baseUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: model,
          prompt: prompt,
          stream: false,
        }),
      });

      if (!response.ok) {
        const errorData = await response.text();
        console.error('Ollama API Response:', response.status, errorData);
        throw new Error(`Ollama API call failed: ${response.status} - ${errorData}`);
      }

      const data = await response.json();
      console.log('Ollama API response:', data);

      // Extract the entire code block (with ``` and closing ```), if present
      const rawContent = data.response;
      const responseContent = this.extractBlock(rawContent);

      return {
        content: responseContent,
      };
    } catch (error) {
      console.error('Error calling Ollama API:', error);
      throw error;
    }
  }
}

export default OllamaAPI;
