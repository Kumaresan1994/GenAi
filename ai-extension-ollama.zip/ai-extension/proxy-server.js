app.use(
  '/',
  createProxyMiddleware({
    target: 'http://localhost:11434',
    changeOrigin: true,
    pathRewrite: {
      '^/': '/api/generate',
    },
    onProxyRes: (proxyRes) => {
      proxyRes.headers['Access-Control-Allow-Origin'] = '*';
      proxyRes.headers['Access-Control-Allow-Methods'] = 'GET, POST, OPTIONS';
      proxyRes.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization';
    },
    onProxyReq: (proxyReq, req) => {
      if (req.method === 'OPTIONS') {
        proxyReq.method = 'GET'; // Change OPTIONS to GET if needed
      }
    },
  })
);
