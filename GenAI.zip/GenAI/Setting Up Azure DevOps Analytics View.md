# Setting Up Azure DevOps Analytics Views for Test Results Dashboard

## Overview
To create an Analytics View for your Selenium/Java/TestNG test results in Azure DevOps, you'll need to follow these steps to track and visualize your automation test outcomes.

## Prerequisites
- Azure DevOps project with build/release pipelines configured
- Test results being published in your pipelines
- Appropriate permissions (you need to be a member of the "Analytics" service account group)

## Step-by-Step Implementation

### 1. Publish Test Results in Your Pipeline
First, ensure your pipeline is publishing test results properly:

```yaml
# Add this to your Azure Pipeline YAML
- task: PublishTestResults@2
  inputs:
    testResultsFormat: 'JUnit' # TestNG outputs JUnit format reports
    testResultsFiles: '**/test-results.xml' # Path to your TestNG results
    mergeTestResults: true
    testRunTitle: 'Sanction Screening Automation Tests'
  condition: succeededOrFailed()
```

### 2. Create an Analytics View

1. **Navigate to Analytics**:
   - Go to your Azure DevOps project
   - Click on "Analytics" under the "Overview" section in the left sidebar

2. **Create New View**:
   - Click on "New View" button
   - Select "Test Results" as the entity type

3. **Configure Basic Settings**:
   - Give your view a name (e.g., "Sanction Screening Test Results")
   - Set the date range (or choose "All available data")
   - Click "Next"

4. **Add Filters**:
   - Add filters to narrow down your test results:
     - `Pipeline/DefinitionName` = [Your pipeline name]
     - `Test/TestType` = "Automated"
     - `Outcome` = "Passed,Failed,NotExecuted" (or select specific outcomes)
   - Click "Next"

5. **Select Dimensions**:
   - Choose how you want to group/slice your data:
     - Recommended dimensions:
       - `Test/TestCaseTitle` (for individual test cases)
       - `Outcome` (pass/fail status)
       - `Build/BuildNumber` (to track across builds)
       - `Date` (for trend analysis)
   - Click "Next"

6. **Select Measures**:
   - Choose what metrics to display:
     - `ResultCount` (total test count)
     - `ResultDuration` (test duration)
     - `ResultErrorCount` (failure count)
   - Click "Create"

### 3. Customize the Dashboard View

1. **Create a New Dashboard**:
   - Go to "Overview" → "Dashboards"
   - Click "+ New dashboard"
   - Name it "Sanction Screening Test Analytics"

2. **Add Analytics Widgets**:
   - Click "Edit" → "Add Widget"
   - Search for and add these widgets:
     - **Test Results Trend**: Shows pass/fail trends over time
     - **Test Results Analytics**: Detailed breakdown of test outcomes
     - **Velocity**: Test execution velocity

3. **Configure Widgets**:
   - For each widget, select the Analytics View you created
   - Customize time period, grouping, and visualization options

### 4. Set Up Advanced Analytics (Optional)

For more advanced tracking:

1. **Failure Analysis**:
   - Create a new Analytics View filtered by `Outcome = Failed`
   - Add dimension `Test/StackTrace` to analyze failure patterns

2. **Flaky Test Detection**:
   - Create a view with:
     - Filter: `Outcome = Failed OR Outcome = Passed`
     - Dimension: `Test/TestCaseTitle`
     - Measure: `ResultCount` grouped by `Outcome`

3. **Execution Time Tracking**:
   - Create a view with:
     - Dimension: `Test/TestCaseTitle`
     - Measure: `ResultDuration` (average)
     - Sort by duration descending to find slow tests

### 5. Share and Maintain the Dashboard

1. **Share with Team**:
   - Set appropriate permissions on the dashboard
   - Pin important widgets to team homepage

2. **Schedule Refresh**:
   - Analytics views typically update within 15-30 minutes
   - For critical metrics, consider using Power BI with direct Azure DevOps Analytics connection for real-time data

## Best Practices

1. **Naming Conventions**:
   - Use consistent naming for test cases to make filtering easier
   - Include the application module in test names (e.g., "SanctionScreen_VerifyHighRiskCustomer")

2. **Data Retention**:
   - Configure test result retention policies in Project Settings
   - Consider exporting historical data if needed beyond retention period

3. **Integration with Work Items**:
   - Link failed tests to bugs automatically in your pipeline
   - Use `##vso[task.addattachment]` to attach screenshots for failed tests

4. **Alerting**:
   - Set up alerts for significant drops in pass percentage
   - Create queries to track open bugs linked to test failures

## Troubleshooting

If you don't see test results in Analytics:
1. Verify the PublishTestResults task is running successfully
2. Check that the test results file is in the correct format and path
3. Wait up to 30 minutes for data to appear in Analytics
4. Verify you have permissions to view Analytics data

Would you like me to elaborate on any specific part of this setup?