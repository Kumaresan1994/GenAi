Prompyt 1:
Context:

Act as AI assistant to convert the DOM Content to Cucumber Feature File.

Instructions:

- Given the following DOM structure:

<input type="text" id="username" class="input" placeholder="Username"> 
<input type="password" id="password" class="input" placeholder="Password"> 
<button id="Login" class="login-button">Log In</button> 

- Generate Cucumber feature file with the following: 

1. Separate Scenario Outlines for each test type like positive, negative and edge
2. Multiple Examples tables with realistic data (minimum 2)
3. Clear error validation for negative cases
4. Boundary value assertions for edge cases

- [MANDATORY] Provide only the feature file and no description needed

Example:

Feature: Login Functionality
As a user ... 

@positive
Scenario Outline: Successful Login with Valid Credentials
<Use Given When ....>

Examples:


Persona:

I am business consultant working on web apps.

prompt 2:
Context:

I am working for salesforce application automation.

Instructions:

Create cucumber feature file for the following login page. The feature file should include the following scenarios:

Step 1) Positive scenarios 
Step 2) for this dom elements: <input type="text" name="username" id="username" placeholder="Username" class="slds-input slds-combobox__input slds-input-has-icon slds-input-has-icon_left-right slds-combobox__input-value" aria-autocomplete="list" aria-expanded="false" aria-controls="combobox-unique-id-1-listbox-unique-id-2" aria-activedescendant="" autocomplete="off" value="">


Output:
# features/login.feature
Feature: Salesforce Login Functionality
  As a Salesforce user
  I want to login to the application
  So that I can access my Salesforce account

  Scenario Outline: Successful login with valid credentials
    Given I am on the Salesforce login page
    When I enter "<username>" in the username field
    And I enter "<password>" in the password field
    And I click the login button
    Then I should be redirected to the Salesforce home page
    And I should see my username "<username>" displayed

    Examples:
      | username            | password  |
      | user@example.com    | validPass1|
      | admin@example.com  | validPass2|

  Scenario: Login with remember me checked
    Given I am on the Salesforce login page
    When I enter "user@example.com" in the username field
    And I enter "validPass1" in the password field
    And I check the "Remember Me" checkbox
    And I click the login button
    Then I should be redirected to the Salesforce home page
    And my username should be remembered for next login

  Scenario: Login after password reset
    Given I am on the Salesforce login page
    When I enter "user@example.com" in the username field
    And I enter "newValidPass1" in the password field
    And I click the login button
    Then I should be redirected to the Salesforce home page
    And I should not see password reset requirements